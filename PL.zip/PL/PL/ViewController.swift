//
//  ViewController.swift
//  PL
//
//  Created by Muhammad Abubakar on 28/08/2023.
//

import UIKit

class ViewController: UIViewController {

    var button: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("Move", for: .normal)
        btn.backgroundColor = .white
        btn.setTitleColor(.black, for: .normal)
        return btn
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .red
        setupViews()
        addTarget()
    }
    
    func setupViews() {
        view.addSubview(button)
        
        NSLayoutConstraint.activate([
            
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            button.widthAnchor.constraint(equalToConstant: 100),
            button.heightAnchor.constraint(equalToConstant: 50)
        
        ])
    }
    func addTarget() {
        button.addTarget(self, action: #selector(moveToNewController), for: .touchUpInside)
    }
    @objc func moveToNewController() {
        present(NewViewController(), animated: true)
    }


}

class NewViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
    }
}
